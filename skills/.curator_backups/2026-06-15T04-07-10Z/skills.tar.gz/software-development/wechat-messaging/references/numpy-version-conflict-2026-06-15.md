# NumPy 版本冲突问题分析与解决方案（2026年6月15日）

## 问题现象

脚本看起来"执行完成"，但什么都没做。pyautogui 的任何操作都不生效，甚至没有报错。

---

## 根本原因分析

### 依赖链条
```
pyautogui (我们直接使用)
    ↓
pyscreeze (pyautogui 内部依赖，用于截图)
    ↓
opencv-python (cv2，图像处理库)
    ↓
numpy (最底层的数值计算库)
```

### 冲突发生过程
1. **2024年底**：NumPy 发布了 **2.0 版本**，这是一个**不向后兼容**的大版本升级
2. **很多旧库**（包括 opencv-python）是用 NumPy 1.x 编译的
3. **冲突发生**：当系统中的 NumPy 升级到 2.x 时，用 1.x 编译的 C 扩展模块无法运行
4. **结果**：
   - `import cv2` 失败
   - `import pyscreeze` 失败  
   - `import pyautogui` 失败
   - 所有键盘鼠标操作**静默失败**

### 错误信息示例
```
AttributeError: _ARRAY_API not found
```

或

```
A module that was compiled using NumPy 1.x cannot be run in
NumPy 2.4.6 as it may crash. To support both 1.x and 2.x
versions of NumPy, modules must be compiled with NumPy 2.0.
```

---

## ✅ 解决方案

### 方案1：降级 NumPy 到 1.x 版本（推荐，最稳定）

```bash
pip install numpy==1.26.4 --force-reinstall
```

**验证修复**：
```bash
python -c "import warnings; warnings.filterwarnings('ignore'); import pyautogui; print('✅ pyautogui 正常工作')"
```

### 方案2：屏蔽警告（临时方案，不推荐）

```python
# 在脚本最开头添加
import warnings
warnings.filterwarnings('ignore')
```

⚠️ **注意**：这只能屏蔽警告，如果真正的导入错误发生，脚本还是会失败。

### 方案3：升级所有依赖到最新版（冒险）

```bash
pip install --upgrade pyautogui pyscreeze pillow opencv-python numpy
```

⚠️ **风险**：可能引入新的兼容性问题，不推荐。

---

## 🔍 验证方法

### 检查 pyautogui 是否能正常导入
```bash
python -c "import pyautogui; print('pyautogui 版本:', pyautogui.__version__)"
```

### 检查 numpy 版本
```bash
python -c "import numpy; print('numpy 版本:', numpy.__version__)"
```

### 完整的健康检查脚本
```python
import warnings
warnings.filterwarnings('ignore')

print("=" * 50)
print("桌面自动化环境健康检查")
print("=" * 50)

try:
    import numpy
    print(f"✅ numpy: {numpy.__version__}")
except Exception as e:
    print(f"❌ numpy 导入失败: {e}")

try:
    import cv2
    print(f"✅ opencv: {cv2.__version__}")
except Exception as e:
    print(f"❌ opencv 导入失败: {e}")

try:
    import pyautogui
    print(f"✅ pyautogui: {pyautogui.__version__}")
except Exception as e:
    print(f"❌ pyautogui 导入失败: {e}")

try:
    import pyperclip
    print(f"✅ pyperclip: 可用")
except Exception as e:
    print(f"❌ pyperclip 导入失败: {e}")

print("=" * 50)
print("如果所有项都是 ✅，说明环境正常")
print("如果有 ❌，根据错误信息修复")
print("=" * 50)
```

---

## 🎯 预防措施

### 1. 升级依赖前先测试
```bash
# 先看看哪些包会被升级
pip install --upgrade numpy --dry-run

# 确认没问题再真正升级
pip install --upgrade numpy
```

### 2. 使用虚拟环境隔离
```bash
# 创建独立的虚拟环境
python -m venv venv

# 激活虚拟环境
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

# 在虚拟环境中安装依赖
pip install pyautogui pyperclip
```

### 3. 冻结依赖版本
```bash
# 生成依赖清单
pip freeze > requirements.txt

# 内容示例：
# numpy==1.26.4
# opencv-python==4.8.1.78
# pyautogui==0.9.54
# pyperclip==1.8.2

# 后续在新环境中恢复：
pip install -r requirements.txt
```

### 4. 脚本开头添加导入检查
```python
try:
    import pyautogui
    import pyperclip
except ImportError as e:
    print(f"❌ 依赖导入失败: {e}")
    print("请运行: pip install pyautogui pyperclip numpy==1.26.4")
    exit(1)
```

---

## 📋 版本兼容性矩阵

| NumPy 版本 | pyautogui 状态 | opencv-python 状态 | 推荐度 |
|-----------|----------------|-------------------|--------|
| 1.26.4 | ✅ 完全正常 | ✅ 完全正常 | ⭐⭐⭐⭐⭐ 推荐 |
| 1.25.x | ✅ 正常 | ✅ 正常 | ⭐⭐⭐⭐ |
| 2.0.x | ❌ 有问题 | ❌ 不兼容 | ⚠️ 避免 |
| 2.4.6 | ❌ 完全失效 | ❌ 不兼容 | ❌ 不要用 |

---

## 🚨 紧急恢复步骤

如果不小心升级了 NumPy 导致 pyautogui 失效：

```bash
# 1. 立即降级到稳定版本
pip install numpy==1.26.4 --force-reinstall

# 2. 验证修复
python -c "import pyautogui; print('✅ 已恢复')"

# 3. 如果还不行，重新安装所有依赖
pip uninstall -y numpy opencv-python pyautogui pyscreeze
pip install pyautogui pyperclip

# 4. 如果还是不行，创建新的虚拟环境
```

---

## 💡 关键教训

1. **不要盲目升级底层库** - NumPy、OpenCV 等底层库的升级可能导致整个依赖链崩溃
2. **静默失败最危险** - 脚本看起来执行成功，但实际上什么都没做，这种问题最难排查
3. **保留降级方案** - 任何升级操作都要有回滚方案
4. **先测试再推广** - 在生产环境使用前，先在测试环境验证所有功能正常

---

## 📌 相关链接

- [NumPy 2.0 迁移指南](https://numpy.org/doc/stable/numpy_2_0_migration_guide.html)
- [pyautogui 官方文档](https://pyautogui.readthedocs.io/)
- [OpenCV 兼容性说明](https://github.com/opencv/opencv-python)

---

**最后更新**：2026年6月15日  
**发现场景**：微信自动化调试中，脚本看起来执行完成但没有任何操作效果
