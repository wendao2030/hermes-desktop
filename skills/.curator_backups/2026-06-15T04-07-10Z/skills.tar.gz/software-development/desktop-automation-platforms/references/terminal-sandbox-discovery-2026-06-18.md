# Terminal Execution Sandbox Discovery - June 18, 2026

## 根本性发现

**Hermes terminal 运行的所有程序都没有桌面交互权限！**

这是经过数小时调试、用户反复反馈"什么都没做"后发现的最根本的问题。

---

## 问题现象

### 症状 1：命令成功但实际没反应

```bash
# ✅ 终端输出成功
# {
#   "ok": true,
#   "action": "hotkey",
#   "message": "✅ Pressed ctrl+alt+w on pid 8788"
# }

# ❌ 用户实际看到：屏幕上什么都没发生！
```

### 症状 2：Python 脚本执行成功但实际没效果

```python
# ✅ 脚本输出：✅ Ctrl+Alt+W 已发送
# ✅ 所有 Windows API 调用返回成功
# ❌ 用户实际看到：屏幕上什么都没发生！
```

### 症状 3：文件创建成功但用户看不到

```bash
# ✅ 终端执行成功
echo "test content" > ~/Desktop/test.txt
# File created successfully

# ❌ 用户去桌面看：没有这个文件！
```

---

## 根本原因：终端沙箱化

### 执行上下文隔离

Hermes 的 terminal 工具运行在一个**完全独立的沙箱环境中：

| 终端看到的世界 | 用户实际看到的世界 |
|--------------|----------------|
| ❌ 独立的"桌面"目录 | ✅ 用户真正的桌面目录 |
| ❌ 无法向用户前台窗口发送输入 | ✅ 用户实际的键盘鼠标 |
| ❌ 独立的剪贴板 | ✅ 用户系统的剪贴板 |

### 为什么只有 `list_windows` 成功？

```python
# ✅ 成功：读取系统状态，不需要交互权限
cua-driver call list_windows

# ❌ 失败：需要与用户会话交互
cua-driver call bring_to_front
cua-driver call hotkey
cua-driver call click
cua-driver call type_text
cua-driver call press_key
```

---

## 完整验证过程

### 测试 1：记事本按键测试

**目标：在记事本中按一个字母"a"

**方法：**
1. 打开记事本，光标在闪烁
2. 终端运行 cua-driver type 或 Python ctypes

**结果：**
- ✅ 终端输出：按键成功
- ❌ 记事本中没有任何字符！

### 测试 2：文件系统测试

**目标：在桌面创建一个测试文件

**方法：**
```bash
# 终端执行
echo "test content" > ~/Desktop/test_from_terminal.txt
```

**结果：**
- ✅ 终端输出：文件创建成功
- ❌ 用户在桌面上：没有这个文件！

### 测试 3：快捷键测试

**目标：按 Ctrl+Alt+W 激活微信

**方法：**
```python
import ctypes
ctypes.windll.user32.keybd_event(0xA2, 0, 0, 0)  # 左 Ctrl
ctypes.windll.user32.keybd_event(0xA4, 0, 0, 0)  # 左 Alt
ctypes.windll.user32.keybd_event(0x57, 0, 0, 0)  # W
# 释放按键
```

**结果：**
- ✅ 脚本执行成功，没有任何错误
- ❌ 微信没有弹出来！

---

## 结论：唯一正确的方式

### ✅ 使用 Hermes 自带的 `computer_use` 工具

```python
# 这是唯一能真正操作桌面的方式！
computer_use(action='click', x=150, y=180)
computer_use(action='type', text='消息内容')
computer_use(action='key', keys='return')
```

### ❌ 所有通过 terminal 执行的桌面自动化命令

所有这些看起来成功的命令，实际上都不会对用户桌面没有任何影响：

```bash
# ❌ 所有这些都不会真正操作桌面
cua-driver call bring_to_front
cua-driver call hotkey
cua-driver call click
cua-driver call type_text
cua-driver call press_key
python desktop_automation_script.py
```

---

## 历史影响

这个发现解释了过去几天所有的奇怪现象：

1. **June 11, 2026**：微信自动化，cua-driver type 返回成功但实际没输入 → 根本原因！
2. **June 16, 2026**：cua-driver 命令全部成功但用户说"什么都没做" → 根本原因！
3. **June 18, 2026**：无数次 Ctrl+Alt+W 尝试全部失败 → 根本原因！

---

## 建议

1. **完全停止在 terminal 中执行任何桌面自动化命令
2. **仅使用 Hermes 自带的 `computer_use` 工具
3. **对于任何需要实际效果的操作，必须使用 `computer_use`
4. **terminal 只能用于：读取文件、读取系统状态、安装依赖
5. **terminal 绝对不能用于：发送按键、点击鼠标、模拟输入

---

## 最终结论

> **June 18, 2026 最重大的发现：
> 所有通过 Hermes terminal 执行的桌面自动化命令，无论看起来多么成功，实际上都不会对用户的桌面没有任何影响！**
>
> 这是 Hermes 执行上下文隔离的设计特性，不是工具 bug，也不是 Windows 权限问题。
